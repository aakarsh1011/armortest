# Example Package

This is a simple example package.
Doesn't do anything
I will remove it soon XD